#!/usr/bin/env python

import rospy
from std_msgs.msg import String,Float32
from AR_week5_test.msg import cubic_traj_params,cubic_traj_coeffs
# from AR_week5_test.srv import *
import matplotlib.pyplot as plt
import numpy as np

p_traj = Float32(1)
v_traj = Float32(1)
a_traj = Float32(1)
def callback(data):
    #rospy.loginfo(rospy.get_caller_id() + 'I heard %.2f', data.t0)
    # msg = compute_cubic_traj()
    a0 = data.a0
    a1 = data.a1
    a2 = data.a2
    a3 = data.a3
    t0 = data.t0
    tf = data.tf
    T = tf - t0
    # position traj
    #T = np.linspace(t0,0.1,tf)
    p_traj = a0 + a1*T + a2*T*T + a3*T*T*T
    # velocity trajectory
    v_traj = a1 + 2*a2*T + 3*a3*T*T
    # acceleration trajectory
    a_traj = 2*a2+6*a3*T
    # plt.figure(num=3,figsize = (8,5))
    # plt.figure(1)
    # plt.plot(T, p_traj)
    # plt.plot(T, v_traj)
    # plt.plot(T, a_traj)
    # plt.show()
    for i in np.arange(t0,tf,0.1):
        p_traj = a0 + a1*i + a2*i*i + a3*i*i*i
        # velocity trajectory
        v_traj = a1 + 2*a2*i + 3*a3*i*i
        # acceleration trajectory
        a_traj = 2*a2+6*a3*i

        try:
            talker(p_traj,v_traj,a_traj)
        except rospy.ROSInterruptException:
            pass
    
    print(data)

def listener():

    # In ROS, nodes are uniquely named. If two nodes with the same
    # name are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('plot_cubic_traj', anonymous=True)

    rospy.Subscriber('cubic_traj_planner', cubic_traj_coeffs, callback)

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()


def talker(p_traj,v_traj,a_traj):
    pub = rospy.Publisher('plot', Float32, queue_size = 10)
    rospy.init_node('plot_cubic_traj', anonymous=True)
    rate = rospy.Rate(1/5)
    # msg = send
    while not rospy.is_shutdown():
        rospy.loginfo(p_traj)
        pub.publish(p_traj)
        pub.publish(v_traj)
        pub.publish(a_traj)
        rate.sleep()





if __name__ == '__main__':
    listener()
    




