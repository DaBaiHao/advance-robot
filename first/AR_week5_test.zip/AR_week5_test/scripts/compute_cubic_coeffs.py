#!/usr/bin/env python

import rospy

from std_msgs.msg import String
from AR_week5_test.msg import cubic_traj_params,cubic_traj_coeffs
from AR_week5_test.srv import *

data_msg = cubic_traj_params()

def compute_cubic_coeffs(req):
	coeffs = cubic_traj_params()
	p0 = req.p0
	pf = req.pf
	v0 = req.v0
	vf = req.vf
	return computeCubicCoeffsResponse(req)








def compute_cubic_coeffs_server():
	rospy.init_node('compute_cubic_coeffs_server')
	s = rospy.Service('compute_cubic_coeffs', compute_cubic_traj, compute_cubic_coeffs)
	print ("Ready to compute_cubic_coeffs.")
	rospy.spin()


if __name__ == "__main__":
	compute_cubic_coeffs_server()